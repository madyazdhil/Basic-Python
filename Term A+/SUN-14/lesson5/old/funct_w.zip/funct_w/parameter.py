#define the function
def perkalian(angka1, angka2):
    print(f"nilai dari {angka1} * {angka2} adalah {angka1*angka2}")

#call the function
perkalian(21, 21)
perkalian(22,22)

JumlahBarang=int(input("Berapa jumlah barang yang anda beli? "))
Harga= JumlahBarang*100

if Harga>1000 and Harga<2000:
    Diskon=Harga*0.1
    print(f"Jumlah barang: {JumlahBarang}\nHarga per barang: 100\nHarga selruhnya:{Harga}\n Diskon:10%\n Total:{Harga - Diskon}")
elif Harga>2000 and Harga<3000:
    Diskon= Harga*0.2
    print(f"Jumlah barang: {JumlahBarang}\nHarga per barang: 100\nHarga selruhnya:{Harga}\n Diskon:20%\n Total:{Harga-Diskon}")
elif Harga>3000 and Harga<4000:
    Diskon= Harga*0.3
    print(f"Jumlah barang: {JumlahBarang}\nHarga per barang: 100\nHarga selruhnya:{Harga}\n Diskon:30%\n Total:{Harga-Diskon}")
elif Harga > 4000 and Harga < 5000:
    Diskon = Harga * 0.4
    print(
        f"Jumlah barang: {JumlahBarang}\nHarga per barang: 100\nHarga selruhnya:{Harga}\n Diskon:40%\n Total:{Harga - Diskon}")
elif Harga>5000 and Harga<6000:
    Diskon= Harga*0.5
    print(f"Jumlah barang: {JumlahBarang}\nHarga per barang: 100\nHarga selruhnya:{Harga}\n Diskon:50%\n Total:{Harga-Diskon}")
else:
    print(f"Jumlah barang: {JumlahBarang}\nHarga per barang: 100\nTotal:{Harga}")
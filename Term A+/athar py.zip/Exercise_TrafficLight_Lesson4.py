WarnaLampu=input("Tuliskan satu warna (merah, kuning atau hijau): ")
if WarnaLampu== "merah":
    print("Warna lampunya merah:Berhenti sebentar")
elif WarnaLampu== "kuning":
    print("Lampunya kuning: Hati Hati teman")
elif WarnaLampu=="hijau":
    print("Lampunya hijau: Silahkan jalan")
else:
    print("Input tidak valid")
    